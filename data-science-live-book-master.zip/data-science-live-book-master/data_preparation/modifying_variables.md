

Modifying variables
===

### What is this about?


•	add scale example
•	add explain the difference between visualizing normal and transformed variables
•	add explanation to save the values from the training set
